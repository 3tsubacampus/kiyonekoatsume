"use strict";

// ============================================================
// キヨ猫あつめ
// ============================================================

const canvas = document.getElementById("game-canvas");
const ctx = canvas.getContext("2d");

const titleScreen = document.getElementById("title-screen");
const gameScreen = document.getElementById("game-screen");
const startButton = document.getElementById("start-button");
const goalValue = document.getElementById("goal-value");
const moneyValue = document.getElementById("money-value");


const popupOverlay = document.getElementById("popup-overlay");
const popupTitle = document.getElementById("popup-title");
const popupContent = document.getElementById("popup-content");
const popupClose = document.getElementById("popup-close");

const collectionNotice = document.getElementById("collection-notice");
const resetButton = document.getElementById("reset-button");

// ------------------------------------------------------------
// ゲーム状態
// ------------------------------------------------------------

let gameStarted = false;
let stage = 1;
let money = 0;
let goal = 10000;

let speedLevel = 0;
let speed = 5;

let multiplierLevel = 0;
let multiplier = 1;

let cats = [];
let pins = [];
let holes = [];

let lastDropTime = 0;
let lastHoleChange = 0;
let animationId = null;
let previousPattern = -1;

let championMode = false;
let stageCleared = false;
let collection = [];
let newCollection = [];
let drawPending = false;
let paused = false;
let completionShown = false;

let bgmVolume = 0.5;
let seVolume = 0.5;
let bgmOn = true;
let seOn = true;
let bgmStarted = false;
let bgmAudio = null;

const MAX_SPEED_LEVEL = 9;
const MIN_DROP_INTERVAL = 0.5;

const PIN_RADIUS = 29;
const HOLE_HEIGHT = 42;
const CAT_RADIUS = 30;


const catEmoji = "🐈‍⬛";


// ------------------------------------------------------------
// ポイント取得履歴（コンソールに自動表示）
// ------------------------------------------------------------

const pointHistory = [];
const MAX_POINT_HISTORY = 200;



// ------------------------------------------------------------
// 色
// ------------------------------------------------------------

const pinColors = {
  2: "#ffe17b",
  3: "#ffad52",
  4: "#ff8bbd",
  5: "#e64b54"
};

const holeColors = {
  1: "#56a34d",
  2: "#56a34d",
  3: "#448fce",
  4: "#448fce",
  5: "#448fce",
  6: "#448fce",
  7: "#9b6acb",
  8: "#9b6acb",
  9: "#9b6acb",
  10: "#9b6acb"
};


// ------------------------------------------------------------
// コレクション
// ------------------------------------------------------------

const collectibleFaces = [
  { id: "smile", name: "笑顔", face: "😺" },
  { id: "cry", name: "泣き顔", face: "😿" },
  { id: "angry", name: "怒り顔", face: "😾" },
  { id: "sulk", name: "すねた顔", face: "🙀" },
  { id: "secret", name: "トップシークレット", face: "🐈‍⬛" }
];


// ------------------------------------------------------------
// ピン配置パターン
// 数値は盤面内の相対位置
// 上部1/3にはピンを配置しない
// ------------------------------------------------------------

const pinPatterns = [
  [[.25,.25],[.75,.25],[.5,.43],[.3,.61],[.7,.61]],
  [[.5,.22],[.25,.4],[.75,.4],[.4,.6],[.6,.6]],
  [[.3,.25],[.7,.25],[.5,.4],[.25,.58],[.75,.58]],
  [[.2,.32],[.5,.25],[.8,.32],[.35,.53],[.65,.53]],
  [[.35,.22],[.65,.22],[.25,.44],[.75,.44],[.5,.62]]
];


// ------------------------------------------------------------
// 基本関数
// ------------------------------------------------------------

function randInt(a, b) {
  return Math.floor(Math.random() * (b - a + 1)) + a;
}


function fmt(n) {
  return Math.floor(n).toLocaleString("ja-JP");
}


function boardW() {
  return canvas.clientWidth;
}


function boardH() {
  return canvas.clientHeight;
}


function updateGoal() {
  goal = stage <= 5
    ? 10000 * Math.pow(10, stage - 1)
    : Infinity;

  goalValue.textContent = stage <= 5 ? fmt(goal) : "∞";
  resetButton.classList.toggle("hidden", stage < 6);
}


function updateMoney() {
  moneyValue.textContent = fmt(money);
}


// ------------------------------------------------------------
// ポイント履歴記録とコンソール表示
// ------------------------------------------------------------

function recordPointGain(type, slotMultiplier, amount, cat) {
  const entry = {
    time: new Date().toLocaleTimeString("ja-JP"),
    stage,
    type,
    multiplier: `×${slotMultiplier}`,
    amount: `+${fmt(amount)}`,
    total: fmt(money),
    catX: Math.round(cat?.x ?? 0),
    catY: Math.round(cat?.y ?? 0)
  };

  pointHistory.push(entry);
  if (pointHistory.length > MAX_POINT_HISTORY) {
    pointHistory.splice(0, pointHistory.length - MAX_POINT_HISTORY);
  }

  // 獲得のたびにログを追加。コンソールを後から開いてもページ読み込み後のログを確認できる。
  console.log(`[ポイント獲得] ${entry.time} | STAGE ${entry.stage} | ${entry.type} ${entry.multiplier} | ${entry.amount} | 合計 ${entry.total}`);
}


function printPointHistory() {
  console.group("🐈 キヨ猫あつめ：ポイント取得履歴");
  if (pointHistory.length === 0) {
    console.info("まだポイント取得履歴はありません。");
  } else {
    console.table(pointHistory);
  }
  console.info("ポイント獲得時に新しいログが自動追加されます。");
  console.groupEnd();
}


// ------------------------------------------------------------
// キャンバス調整
// ------------------------------------------------------------

function resizeCanvas() {
  const rect = canvas.getBoundingClientRect();
  if (!rect.width || !rect.height) return;

  const dpr = window.devicePixelRatio || 1;
  canvas.width = Math.floor(rect.width * dpr);
  canvas.height = Math.floor(rect.height * dpr);
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

  // canvasのサイズ変更で描画内容が消えるため、穴の位置と寸法も現在の画面サイズに合わせて再計算する。
  if (holes.length === 3) {
    const w = rect.width;
    const h = rect.height;
    const holeW = w / 3;
    holes.forEach((hole, i) => {
      hole.x = i * holeW;
      hole.width = holeW;
      hole.y = h - HOLE_HEIGHT;
      hole.height = HOLE_HEIGHT;
    });
  }

  if (gameStarted) drawBoard();
}


window.addEventListener("resize", resizeCanvas);


// ------------------------------------------------------------
// ゲーム開始
// ------------------------------------------------------------

startButton.addEventListener("click", () => {
  titleScreen.classList.remove("active");
  gameScreen.classList.add("active");
  gameStarted = true;

  resizeCanvas();
  createBoard();
  lastDropTime = performance.now();
  lastHoleChange = Date.now();
  startGameTicker();
});


// ------------------------------------------------------------
// 盤面作成
// ------------------------------------------------------------

function createBoard() {
  const w = boardW();
  const h = boardH();
  if (!w || !h) return;

  // 底部の倍率穴を3つ、隙間なく並べる
  holes = [];
  const holeW = w / 3;

  for (let i = 0; i < 3; i++) {
    holes.push({
      x: i * holeW,
      width: holeW,
      y: h - HOLE_HEIGHT,
      height: HOLE_HEIGHT,
      multiplier: championMode ? 99 : randInt(1, 10)
    });
  }

  // 直前と同じピン配置は避ける
  let p;
  do {
    p = randInt(0, pinPatterns.length - 1);
  } while (p === previousPattern);
  previousPattern = p;

  const layout = pinPatterns[p];
  const requestedCount = randInt(3, 5);
  pins = [];
  const multCounts = {};

  // 猫（直径60px）がピン同士の間を通れるように、
  // ピンの中心間距離を「ピン直径 + 猫直径 + 余裕」にする。
  const catPassageGap = 8;
  const minPinCenterDistance = PIN_RADIUS * 2 + CAT_RADIUS * 2 + catPassageGap;
  const candidates = layout.map(pos => ({
    x: w * pos[0],
    // 縦幅の上1/3を避け、下2/3側に配置
    y: h * (1 / 3 + pos[1] * (2 / 3))
  }));

  // パターン上の候補から、猫が通れる間隔を保てるピンだけ採用する。
  // 条件を満たせない場合はピン数を減らし、狭い通路を作らない。
  const selected = [];
  for (const candidate of candidates) {
    if (selected.every(pin => Math.hypot(candidate.x - pin.x, candidate.y - pin.y) >= minPinCenterDistance)) {
      selected.push(candidate);
      if (selected.length >= requestedCount) break;
    }
  }

  selected.forEach(pos => {
    let m;
    do {
      m = randInt(2, 5);
    } while ((multCounts[m] || 0) >= 2);
    multCounts[m] = (multCounts[m] || 0) + 1;

    pins.push({
      x: pos.x,
      y: pos.y,
      radius: PIN_RADIUS,
      multiplier: m
    });
  });

  drawBoard();
}


function randomHoleMultiplier() {
  return randInt(1, 10);
}


function changeHoleMultipliers() {
  holes.forEach(hole => {
    hole.multiplier = championMode ? 99 : randomHoleMultiplier();
  });
  lastHoleChange = Date.now();
}


// ------------------------------------------------------------
// 猫の排出
// 横幅中央1/3の中でランダムに排出
// ------------------------------------------------------------

function dropCat() {
  const w = boardW();
  const third = w / 3;
  const centerLeft = third;
  const centerRight = third * 2;
  const margin = CAT_RADIUS + 2;
  const minX = centerLeft + margin;
  const maxX = centerRight - margin;
  const spawnX = minX + Math.random() * Math.max(1, maxX - minX);

  cats.push({
    x: spawnX,
    y: CAT_RADIUS + 2,
    radius: CAT_RADIUS,
    vx: (Math.random() - 0.5) * 0.35,
    vy: 0,
    rotation: Math.random() * Math.PI * 2,
    spin: (Math.random() - 0.5) * 0.012,
    pinTouching: new Set()
  });
}


// ------------------------------------------------------------
// ピン衝突とポイント加算
// 接触開始時に1回だけ加算し、接触が途切れた後の再接触は再加算
// ------------------------------------------------------------

function checkPinCollision(cat, pin, index, frameContacts) {
  const dx = cat.x - pin.x;
  const dy = cat.y - pin.y;
  const dist = Math.hypot(dx, dy);
  const minDist = cat.radius + pin.radius;
  if (dist >= minDist) return;

  // 新しく触れた瞬間のみポイント加算（同一フレーム内の複数サブステップも抑止）
  if (!cat.pinTouching?.has(index) && !frameContacts.has(index)) {
    const gained = multiplier * pin.multiplier;
    money += gained;
    updateMoney();
    recordPointGain("倍率ピン", pin.multiplier, gained, cat);

    if (stage <= 5 && money >= goal && !stageCleared) {
      stageCleared = true;
      showClearButton();
    }
  }
  frameContacts.add(index);

  const nx = dx / (dist || 1);
  const ny = dy / (dist || 1);
  const overlap = minDist - dist;
  cat.x += nx * (overlap + 0.8);
  cat.y += ny * (overlap + 0.8);

  const dot = cat.vx * nx + cat.vy * ny;
  if (dot < 0) {
    const restitution = 3.25;
    cat.vx -= restitution * dot * nx;
    cat.vy -= restitution * dot * ny;
    cat.vy -= 1.9;
    cat.vx += (Math.random() - 0.5) * 0.7;
  }
  cat.spin += (Math.random() - 0.5) * 0.1;
}


// ------------------------------------------------------------
// ポイント加算：倍率穴
// ------------------------------------------------------------

function awardHole(cat, hole) {
  const gained = multiplier * hole.multiplier;
  money += gained;
  updateMoney();
  recordPointGain("倍率穴", hole.multiplier, gained, cat);

  if (stage <= 5 && money >= goal && !stageCleared) {
    stageCleared = true;
    showClearButton();
  }
}


// ------------------------------------------------------------
// 猫の物理演算
// ------------------------------------------------------------

function updateCats(dt) {
  const w = boardW();
  const h = boardH();
  const scale = Math.min(dt / 16.67, 2);
  const gravity = 0.075;
  const terminal = 2.25;

  cats.forEach(cat => {
    cat.vy = Math.min(terminal, cat.vy + gravity * scale);
    cat.vx += Math.sin(performance.now() / 950 + cat.rotation) * 0.008 * scale;
    cat.vx = Math.max(-1.15, Math.min(1.15, cat.vx));
    cat.rotation += cat.spin * scale;

    // 今フレームに接触したピンを記録し、接触が切れたピンは次回再加算可能にする。
    const frameContacts = new Set();
    const travel = Math.max(Math.abs(cat.vx * scale), Math.abs(cat.vy * scale));
    const steps = Math.max(1, Math.ceil(travel / Math.max(4, cat.radius * 0.22)));
    const stepScale = scale / steps;

    for (let step = 0; step < steps; step++) {
      cat.x += cat.vx * stepScale;
      cat.y += cat.vy * stepScale;

      if (cat.x - cat.radius < 0) {
        cat.x = cat.radius;
        cat.vx = Math.abs(cat.vx) * 0.75;
      }
      if (cat.x + cat.radius > w) {
        cat.x = w - cat.radius;
        cat.vx = -Math.abs(cat.vx) * 0.75;
      }
      if (cat.y - cat.radius < 0) {
        cat.y = cat.radius;
        cat.vy = Math.abs(cat.vy) * 0.75;
      }

      pins.forEach((pin, i) => checkPinCollision(cat, pin, i, frameContacts));
    }
    cat.pinTouching = frameContacts;
  });


  // 底の穴は横幅全体を覆う
  cats = cats.filter(cat => {
    const holeTop = h - HOLE_HEIGHT;
    if (cat.y + cat.radius >= holeTop) {
      const x = Math.max(0, Math.min(w - 0.01, cat.x));
      const hole = holes.find(q => x >= q.x && x < q.x + q.width) || holes[2];
      awardHole(cat, hole);
      return false;
    }

    if (cat.y - cat.radius > h) {
      const index = Math.min(2, Math.floor(cat.x / (w / 3)));
      awardHole(cat, holes[index]);
      return false;
    }
    return true;
  });
}


// ------------------------------------------------------------
// 描画
// ------------------------------------------------------------

function drawBoard() {
  const w = boardW();
  const h = boardH();
  if (!w || !h) return;

  ctx.clearRect(0, 0, w, h);
  ctx.fillStyle = "#fff8e9";
  ctx.fillRect(0, 0, w, h);

  // ピン
  pins.forEach(pin => {
    ctx.beginPath();
    ctx.arc(pin.x, pin.y, pin.radius, 0, Math.PI * 2);
    ctx.fillStyle = pinColors[pin.multiplier];
    ctx.fill();
    ctx.strokeStyle = "#6a4b27";
    ctx.lineWidth = 2.2;
    ctx.stroke();

    ctx.fillStyle = "#000";
    ctx.font = "bold 19px sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("×" + pin.multiplier, pin.x, pin.y);
  });

  // 底部の倍率穴
  holes.forEach(hole => {
    ctx.fillStyle = holeColors[hole.multiplier] || "#8c65b8";
    ctx.fillRect(hole.x, hole.y, hole.width, hole.height);
    ctx.strokeStyle = "#5c472c";
    ctx.lineWidth = 1.5;
    ctx.strokeRect(hole.x, hole.y, hole.width, hole.height);

    ctx.fillStyle = "#fff";
    ctx.font = "bold 19px sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("×" + hole.multiplier, hole.x + hole.width / 2, hole.y + hole.height / 2);
  });

  // 落下中の猫
  cats.forEach(cat => {
    ctx.save();
    ctx.translate(cat.x, cat.y);
    ctx.rotate(cat.rotation);
    ctx.font = `${cat.radius * 2}px sans-serif`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(catEmoji, 0, 0);
    ctx.restore();
  });
}


// ------------------------------------------------------------
// ゲーム進行
// ------------------------------------------------------------

function gameLoop(now) {
  if (!gameStarted || paused) return;
  const dt = Math.max(0, now - (gameLoop.lastTime || now));
  gameLoop.lastTime = now;

  if (now - lastDropTime >= speed * 1000) {
    dropCat();
    lastDropTime = now;
  }

  if (Date.now() - lastHoleChange >= 60000) {
    changeHoleMultipliers();
  }

  let remaining = dt;
  while (remaining > 0) {
    const slice = Math.min(remaining, 16.67);
    updateCats(slice);
    remaining -= slice;
  }
  drawBoard();
}


// ------------------------------------------------------------
// 描画フレームに依存しない定期更新
// DevToolsを開いてもゲーム処理を続けるためのタイマー
// ------------------------------------------------------------

const GAME_TICK_MS = 16;


function startGameTicker() {
  if (animationId !== null) return;
  gameLoop.lastTime = performance.now();
  animationId = window.setInterval(() => gameLoop(performance.now()), GAME_TICK_MS);
}


function stopGameTicker() {
  if (animationId === null) return;
  window.clearInterval(animationId);
  animationId = null;
}


// ------------------------------------------------------------
// ステージクリア
// ------------------------------------------------------------

function showClearButton() {
  if (document.getElementById("stage-clear-button")) return;
  const button = document.createElement("button");
  button.id = "stage-clear-button";
  button.className = "stage-clear";
  button.textContent = "もくひょうたっせい！";

  // 「もくひょうたっせい！」を、画面上のクリア目標数字に重ねて表示。
  // fixed位置なのでゲーム盤の親レイアウトに影響しない。
  button.style.position = "fixed";
  button.style.zIndex = "9999";
  button.style.display = "flex";
  button.style.alignItems = "center";
  button.style.justifyContent = "center";
  button.style.whiteSpace = "nowrap";
  button.style.margin = "0";
  button.style.padding = "0";
  button.style.transform = "none";
  button.style.left = "0px";
  button.style.top = "0px";
  button.style.width = "auto";
  button.style.height = "auto";
  button.style.fontSize = "clamp(14px, 4vw, 24px)";

  const positionClearButton = () => {
    const rect = goalValue.getBoundingClientRect();
    button.style.left = `${rect.left}px`;
    button.style.top = `${rect.top}px`;
    button.style.width = `${rect.width}px`;
    button.style.height = `${rect.height}px`;
  };

  button.onclick = () => {
    paused = true;
    openLotteryBefore();
  };

  document.body.appendChild(button);
  positionClearButton();
  button._positionClearButton = positionClearButton;
  window.addEventListener("resize", positionClearButton);
}


function removeClearButton() {
  const button = document.getElementById("stage-clear-button");
  if (!button) return;
  if (button._positionClearButton) {
    window.removeEventListener("resize", button._positionClearButton);
  }
  button.remove();
}


function openLotteryBefore() {
  openPopup(
    "ステージクリア！",
    `
      <div class="popup-item popup-text">
        <p>目標達成！</p>
        <p>くじに挑戦しよう！</p>
        <button id="lottery-draw">くじを引く！</button>
      </div>
    `
  );
  document.getElementById("lottery-draw").onclick = drawCollection;
}


// ------------------------------------------------------------
// コレクション抽選
// ------------------------------------------------------------

function drawCollection() {
  const available = collectibleFaces.filter(c => !collection.includes(c.id));
  if (!available.length) {
    finishStage();
    return;
  }

  const prize = available[randInt(0, available.length - 1)];
  collection.push(prize.id);
  newCollection.push(prize.id);
  collectionNotice.classList.remove("hidden");

  openPopup(
    "NEW！",
    `
      <div class="popup-item popup-text">
        <div style="font-size:72px">${prize.face}</div>
        <h3>NEW！ ${prize.name}</h3>
        <p>コレクションに追加されたよ！</p>
        <button id="reveal-continue">つぎへ</button>
      </div>
    `
  );

  document.getElementById("reveal-continue").onclick = () => {
    closePopup();
    finishStage();
  };
}


// ------------------------------------------------------------
// ステージ終了・次のステージ
// ------------------------------------------------------------

function finishStage() {
  removeClearButton();
  stageCleared = false;
  paused = false;

  if (collection.length >= 5 && !completionShown) {
    completionShown = true;
    stage = 6;
    updateGoal();

    openPopup(
      "絶対王者！",
      `
        <div class="popup-item popup-text">
          <div style="font-size:58px">♛ 🐈‍⬛ ♛</div>
          <h3>コンプリート！！</h3>
          <p>絶対王者の称号を手に入れた！</p>
          <button id="champion-continue">つづける</button>
        </div>
      `
    );

    document.getElementById("champion-continue").onclick = () => {
      closePopup();
      updateGoal();
      createBoard();
      resumeLoop();
    };
    return;
  }


  stage++;
  updateGoal();
  createBoard();
  resumeLoop();
}


function resumeLoop() {
  paused = false;
  gameLoop.lastTime = performance.now();
  lastDropTime = performance.now();
  if (animationId === null) startGameTicker();
}


// ------------------------------------------------------------
// ポップアップ
// ------------------------------------------------------------

function openPopup(title, html) {
  popupTitle.textContent = title;
  popupContent.innerHTML = html;
  popupOverlay.classList.remove("hidden");
}


function closePopup() {
  popupOverlay.classList.add("hidden");
}


popupClose.addEventListener("click", () => {
  closePopup();
  if (
    paused &&
    popupTitle.textContent !== "これくしょん" &&
    popupTitle.textContent !== "せってい" &&
    popupTitle.textContent !== "つうじょうきょうか"
  ) {
    resumeLoop();
  }
});


popupOverlay.addEventListener("click", e => {
  if (e.target === popupOverlay) closePopup();
});


// ------------------------------------------------------------
// メニュー
// ------------------------------------------------------------

document.querySelectorAll(".menu-button").forEach(button => {
  button.addEventListener("click", () => {
    const menu = button.dataset.menu;
    if (menu === "upgrade") openUpgradeMenu();
    if (menu === "collection") openCollectionMenu();
    if (menu === "settings") openSettingsMenu();
  });
});


// ------------------------------------------------------------
// 強化
// ------------------------------------------------------------

function speedCost() {
  return Math.ceil(10 * Math.pow(1.65, speedLevel));
}


function multiplierCost() {
  return Math.ceil(5 * Math.pow(1.7, multiplierLevel));
}


function openUpgradeMenu() {
  openPopup(
    "つうじょうきょうか",
    `
      <div class="popup-item">
        <strong>そくど</strong>
        <p>現在：${speed.toFixed(1)}秒</p>
        <p>Lv.${speedLevel}/${MAX_SPEED_LEVEL}</p>
        <p>次の強化：${speedCost().toLocaleString()}円</p>
        <button
          id="speed-up"
          class="${money < speedCost() || speedLevel >= MAX_SPEED_LEVEL ? "cannot-afford" : ""}"
          ${money < speedCost() || speedLevel >= MAX_SPEED_LEVEL ? "disabled" : ""}
        >強化する</button>
      </div>


      <div class="popup-item">
        <strong>ばいりつ</strong>
        <p>現在：${multiplier}円</p>
        <p>Lv.${multiplierLevel}</p>
        <p>次の強化：${multiplierCost().toLocaleString()}円</p>
        <button
          id="mult-up"
          class="${money < multiplierCost() ? "cannot-afford" : ""}"
          ${money < multiplierCost() ? "disabled" : ""}
        >強化する</button>
      </div>
    `
  );

  document.getElementById("speed-up").onclick = () => {
    const cost = speedCost();
    if (money < cost || speedLevel >= MAX_SPEED_LEVEL) return;
    money -= cost;
    speedLevel++;
    speed = Math.max(MIN_DROP_INTERVAL, 5 - speedLevel * 0.5);
    updateMoney();
    openUpgradeMenu();
  };

  document.getElementById("mult-up").onclick = () => {
    const cost = multiplierCost();
    if (money < cost) return;
    money -= cost;
    multiplierLevel++;
    multiplier = multiplierLevel + 1;
    updateMoney();
    openUpgradeMenu();
  };
}


// ------------------------------------------------------------
// コレクション画面
// ------------------------------------------------------------

function openCollectionMenu() {
  collectionNotice.classList.add("hidden");
  const cards = collectibleFaces.map(c => {
    const owned = collection.includes(c.id);
    const isSecret = c.id === "secret";
    return `
      <div class="popup-item popup-text collection-card ${isSecret ? "secret-card" : ""}">
        ${isSecret ? '<div class="throne-layer" aria-hidden="true">♛</div>' : ""}
        <div class="collection-face">${owned ? c.face : "🔒"}</div>
        <p class="collection-name">${owned ? c.name : "SECRET"}</p>
        ${newCollection.includes(c.id) ? '<strong style="color:#ffdf38">NEW！</strong>' : ""}
      </div>
    `;
  }).join("");


  openPopup("これくしょん", `<div class="collection-grid">${cards}</div>`);
  newCollection = [];
}


// ------------------------------------------------------------
// 設定
// ------------------------------------------------------------

function openSettingsMenu() {
  openPopup(
    "せってい",
    `
      <div class="popup-item">
        <strong>BGM</strong>
        <label class="toggle-line">
          <input type="checkbox" id="bgm-toggle" ${bgmOn ? "checked" : ""}> ON
        </label>
        <input id="bgm-slider" type="range" min="0" max="100" value="${bgmVolume * 100}">
      </div>

      <div class="popup-item">
        <strong>効果音</strong>
        <label class="toggle-line">
          <input type="checkbox" id="se-toggle" ${seOn ? "checked" : ""}> ON
        </label>
        <input id="se-slider" type="range" min="0" max="100" value="${seVolume * 100}">
      </div>

      <div class="popup-item">
        <strong>絶対王者モード</strong>
        <label class="toggle-line">
          <input type="checkbox" id="champ-toggle" ${championMode ? "checked" : ""}>
          ON（穴倍率×99）
        </label>
      </div>
    `
  );

  document.getElementById("bgm-toggle").onchange = e => {
    bgmOn = e.target.checked;
  };
  document.getElementById("bgm-slider").oninput = e => {
    bgmVolume = Number(e.target.value) / 100;
  };
  document.getElementById("se-toggle").onchange = e => {
    seOn = e.target.checked;
  };
  document.getElementById("se-slider").oninput = e => {
    seVolume = Number(e.target.value) / 100;
  };
  document.getElementById("champ-toggle").onchange = e => {
    championMode = e.target.checked;
    holes.forEach(hole => {
      hole.multiplier = championMode ? 99 : randomHoleMultiplier();
    });
    drawBoard();
  };
}


// ------------------------------------------------------------
// さいしょから
// ------------------------------------------------------------

resetButton.addEventListener("click", () => {
  openPopup(
    "さいしょから？",
    `
      <div class="popup-item popup-text">
        <p>さいしょからはじめると、すべてのデータがリセットされるよ。</p>
        <p>これくしょんもぜんぶなくなるよ！</p>
        <button id="reset-cancel">やめる</button>
        <button id="reset-confirm">さいしょから</button>
      </div>
    `
  );
});


popupContent.addEventListener("click", e => {
  if (e.target.id === "reset-cancel") closePopup();
  if (e.target.id === "reset-confirm") {
    stage = 1;
    money = 0;
    speedLevel = 0;
    speed = 5;
    multiplierLevel = 0;
    multiplier = 1;
    collection = [];
    newCollection = [];
    completionShown = false;
    stageCleared = false;
    paused = false;

    // さいしょから時はポイント履歴もリセットし、新しい履歴開始をコンソールに明示
    pointHistory.length = 0;
    console.info("[キヨ猫あつめ] さいしょから開始。ポイント履歴をリセットしました。");

    updateGoal();
    updateMoney();
    closePopup();
    createBoard();
    resumeLoop();
  }
});


// ------------------------------------------------------------
// 初期表示
// ------------------------------------------------------------

updateGoal();
updateMoney();

console.info("キヨ猫あつめ 起動準備完了");
console.info("ポイント獲得ログは獲得時に自動表示されます。最新履歴はこのページを開いている間、最大200件保存されます。");
printPointHistory();
